/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab05;

/**
 *
 * @author ASUS
 */

interface Human01{
    int legNum = 2;
    int eyeNum = 2;
    void run(Double speed);
    void sleep(String type, int time);
    
}
